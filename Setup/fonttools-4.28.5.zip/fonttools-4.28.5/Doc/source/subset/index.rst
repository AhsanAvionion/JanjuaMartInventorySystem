######
subset
######

.. toctree::
   :maxdepth: 1

   cff

.. automodule:: fontTools.subset
   :inherited-members:
   :members:
   :undoc-members:
