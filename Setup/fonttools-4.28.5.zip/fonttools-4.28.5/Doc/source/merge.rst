####################################
merge: Merge multiple fonts into one
####################################

``fontTools.merge`` provides both a library and a command line interface
(``fonttools merge``) for merging multiple fonts together.

.. autoclass:: fontTools.merge.Merger
   :inherited-members:
   :members:
