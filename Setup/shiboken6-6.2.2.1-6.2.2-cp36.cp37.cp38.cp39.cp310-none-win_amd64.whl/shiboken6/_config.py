shiboken_library_soversion = str(6.2)

version = "6.2.2.1"
version_info = (6, 2, 2.1, "", "")

__build_date__ = '2021-12-08T09:40:21+00:00'




__setup_py_package_version__ = '6.2.2.1'
